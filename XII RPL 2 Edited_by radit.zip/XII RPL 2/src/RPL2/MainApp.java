package RPL2;
import RPL2.Siswa.Tes;
import java.util.Scanner;

public class MainApp {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    System.out.println("=== Input Data Siswa ===");
    System.out.print("Masukkan Nama  : ");
    String nama = input.nextLine();

    String nis;
    do {
    System.out.print("Masukkan NIS   : ");
    nis = input.nextLine();
    if (!Tes.isNISValid(nis)) {
        System.out.println("NIS TIDAK VALID! HANYA 10 ANGKA.");
        }
    } while (!Tes.isNISValid(nis));


    System.out.print("Masukkan Kelas : ");
    String kelas = input.nextLine();

    Tes tes = new Tes(nama, nis, kelas);
    tes.tampilkanData();
    }
}
