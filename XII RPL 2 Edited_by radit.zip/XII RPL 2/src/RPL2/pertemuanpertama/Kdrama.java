package RPL2.pertemuanpertama;
import java.util.ArrayList;
import java.util.Scanner;

public class Kdrama {

    static class KDrama {
        String judul, genre, deskripsi;
        int tahun;
        ArrayList<Integer> ratings = new ArrayList<>();
        ArrayList<String> komentar = new ArrayList<>();

        KDrama(String judul, String genre, int tahun, String deskripsi) {
            this.judul = judul;
            this.genre = genre;
            this.tahun = tahun;
            this.deskripsi = deskripsi;
        }

        void tampilkanInfo() {
            System.out.println("\n=== Info Drama ===");
            System.out.println("Judul    : " + judul);
            System.out.println("Genre    : " + genre);
            System.out.println("Tahun    : " + tahun);
            System.out.println("Deskripsi: " + deskripsi);
            System.out.printf("Rating rata-rata: %.2f dari %d ulasan\n", getAverageRating(), ratings.size());
            System.out.println("Komentar:");
            if (komentar.isEmpty()) System.out.println(" - Belum ada komentar.");
            else komentar.forEach(k -> System.out.println(" - " + k));
        }

        void tambahRating(int rating) {
            if (rating >= 1 && rating <= 5) ratings.add(rating);
        }

        double getAverageRating() {
            if (ratings.isEmpty()) return 0;
            int sum = 0;
            for (int r : ratings) sum += r;
            return (double) sum / ratings.size();
        }

        void tambahKomentar(String text) {
            komentar.add(text);
        }

        String getDeskripsiSingkat() {
            return deskripsi.length() > 50 ? deskripsi.substring(0, 50) + "..." : deskripsi;
        }
    }

    static class User {
        String username, genreFavorit;

        User(String username, String genreFavorit) {
            this.username = username;
            this.genreFavorit = genreFavorit;
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // List drama terbaru & trending 2024-2025
        KDrama[] dramas = {
                new KDrama("The Glory", "Drama, Revenge", 2023,
                        "Seorang wanita yang telah mengalami bullying berat merencanakan balas dendam terhadap pelaku masa lalunya."),
                new KDrama("Twenty-Five Twenty-One", "Romance, Drama, Youth", 2022,
                        "Kisah cinta dan perjuangan dua remaja di masa krisis finansial Korea Selatan tahun 1998."),
                new KDrama("Our Blues", "Drama, Slice of Life", 2022,
                        "Cerita kehidupan sehari-hari dan kisah cinta beragam karakter di pulau Jeju."),
                new KDrama("Pachinko", "Drama, History", 2022,
                        "Sebuah saga keluarga Korea yang berjuang melintasi berbagai generasi dan benua."),
                new KDrama("Extraordinary Attorney Woo", "Legal, Drama", 2022,
                        "Seorang pengacara muda dengan autisme yang sangat cerdas dan penuh semangat."),
                new KDrama("Alchemy of Souls", "Fantasy, Romance", 2022,
                        "Dunia sihir dan kisah cinta yang rumit antara para penyihir muda."),
                new KDrama("Soundtrack #1", "Romance, Drama", 2022,
                        "Dua musisi yang dulunya sahabat lama bertemu kembali dan mulai merasakan cinta."),
                new KDrama("Reborn Rich", "Drama, Fantasy", 2022,
                        "Seorang pria yang dibunuh secara tragis bereinkarnasi ke dalam keluarga konglomerat."),
                new KDrama("Kill Heel", "Drama, Thriller", 2022,
                        "Pertarungan sengit antara wanita-wanita kuat di dunia bisnis fashion."),
                new KDrama("Business Proposal", "Romance, Comedy", 2022,
                        "Seorang wanita menyamar untuk pergi pada kencan buta atas nama teman dan bertemu bosnya."),
                // Tambah drama lain sesuai update terbaru
                new KDrama("My Liberation Notes", "Drama, Slice of Life", 2022,
                        "Tiga saudara yang mencari pembebasan dari kehidupan monoton mereka."),
                new KDrama("Forecasting Love and Weather", "Romance, Drama", 2022,
                        "Kisah romansa dan tantangan kerja di kantor BMKG Korea."),
                new KDrama("Our Blues 2", "Drama, Slice of Life", 2023,
                        "Kelanjutan cerita kehidupan beragam karakter di Jeju, dengan kisah dan konflik baru."),
                new KDrama("Jirisan", "Mystery, Thriller", 2021,
                        "Tim penjaga taman nasional melacak misteri dan menyelamatkan pendaki."),
                new KDrama("Big Mouth", "Legal, Thriller", 2022,
                        "Seorang pengacara berjuang membersihkan namanya setelah terjebak kasus kriminal."),
        };

        System.out.println("=== Selamat datang di K-Drama Selector! ===");
        System.out.print("Masukkan username kamu: ");
        String username = input.nextLine();
        System.out.print("Masukkan genre K-Drama favorit kamu: ");
        String genreFavorit = input.nextLine();
        User user = new User(username, genreFavorit);

        boolean running = true;
        while (running) {
            System.out.println("\nHai " + user.username + ", pilih menu:");
            System.out.println("1. Lihat daftar drama");
            System.out.println("2. Quiz tebak drama");
            System.out.println("3. Chat dengan bot");
            System.out.println("4. Rekomendasi drama berdasarkan genre favorit");
            System.out.println("0. Keluar");
            System.out.print("Pilihan: ");

            String pilihan = input.nextLine();

            switch (pilihan) {
                case "1":
                    lihatDaftarDrama(input, dramas, user);
                    break;
                case "2":
                    mulaiQuiz(input, dramas);
                    break;
                case "3":
                    mulaiChat(input);
                    break;
                case "4":
                    rekomendasiDrama(user, dramas);
                    break;
                case "0":
                    running = false;
                    System.out.println("Terima kasih sudah menggunakan program ini!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid, coba lagi.");
            }
        }

        input.close();
    }

    static void lihatDaftarDrama(Scanner input, KDrama[] dramas, User user) {
        while (true) {
            System.out.println("\n=== Daftar K-Drama ===");
            for (int i = 0; i < dramas.length; i++) {
                System.out.printf("%d. %s\n", i + 1, dramas[i].judul);
            }
            System.out.println("0. Kembali");

            System.out.print("Pilih nomor drama untuk info detail: ");
            int nomor = -1;
            try {
                nomor = Integer.parseInt(input.nextLine());
            } catch (Exception ignored) {}

            if (nomor == 0) break;
            else if (nomor > 0 && nomor <= dramas.length) {
                KDrama drama = dramas[nomor - 1];
                drama.tampilkanInfo();

                System.out.print("Beri rating (1-5), atau 0 untuk skip: ");
                int rating = -1;
                try {
                    rating = Integer.parseInt(input.nextLine());
                    if (rating >= 1 && rating <= 5) {
                        drama.tambahRating(rating);
                        System.out.println("Terima kasih atas ratingnya!");
                    } else if (rating != 0) System.out.println("Rating tidak valid, dilewati.");
                } catch (Exception e) {
                    System.out.println("Input tidak valid, rating dilewati.");
                }

                System.out.print("Tambah komentar? (y/n): ");
                String jawab = input.nextLine().trim().toLowerCase();
                if (jawab.equals("y")) {
                    System.out.print("Tulis komentar: ");
                    String komentar = input.nextLine();
                    drama.tambahKomentar(user.username + ": " + komentar);
                    System.out.println("Komentar berhasil ditambahkan.");
                }

                System.out.println("Tekan Enter untuk kembali...");
                input.nextLine();
            } else System.out.println("Pilihan tidak valid, coba lagi.");
        }
    }

    static void rekomendasiDrama(User user, KDrama[] dramas) {
        System.out.println("\n=== Rekomendasi Drama untuk genre: " + user.genreFavorit + " ===");
        boolean ada = false;
        for (KDrama d : dramas) {
            if (d.genre.toLowerCase().contains(user.genreFavorit.toLowerCase())) {
                System.out.println("- " + d.judul);
                ada = true;
            }
        }
        if (!ada) System.out.println("Maaf, tidak ada rekomendasi untuk genre tersebut.");
    }

    static void mulaiQuiz(Scanner input, KDrama[] dramas) {
        System.out.println("\n=== Quiz Tebak K-Drama ===");
        int skor = 0;
        for (KDrama d : dramas) {
            System.out.println("\nDeskripsi: " + d.getDeskripsiSingkat());
            System.out.print("Tebak judul drama: ");
            String jawaban = input.nextLine();
            if (jawaban.equalsIgnoreCase(d.judul)) {
                System.out.println("Benar!");
                skor++;
            } else {
                System.out.println("Salah! Jawaban benar: " + d.judul);
            }
        }
        System.out.println("\nQuiz selesai! Skor kamu: " + skor + "/" + dramas.length);
    }

    static void mulaiChat(Scanner input) {
        System.out.println("\n=== Chatbot K-Drama ===");
        System.out.println("Halo! Aku bot yang suka K-Drama. Ayo ngobrol!");
        while (true) {
            System.out.print("Kamu: ");
            String pesan = input.nextLine().toLowerCase();
            if (pesan.contains("halo") || pesan.contains("hai")) {
                System.out.println("Bot: Halo juga! Drama apa yang kamu suka?");
            } else if (pesan.contains("romance")) {
                System.out.println("Bot: Drama romance memang seru ya! Pernah nonton \"The Glory\"?");
            } else if (pesan.contains("bye") || pesan.contains("exit")) {
                System.out.println("Bot: Sampai jumpa! Selamat menonton K-Drama!");
                break;
            } else {
                System.out.println("Bot: Wah, menarik! Ceritain dong drama favorit kamu.");
            }
        }
    }
}
