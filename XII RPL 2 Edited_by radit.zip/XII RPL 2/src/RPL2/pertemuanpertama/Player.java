package RPL2.pertemuanpertama;

public class Player {
    private String username;
    private String playerId;
    private int level;

    public Player(String username, String playerId, int level) {
        this.username = username;
        this.playerId = playerId;
        this.level = level;
    }

    public void tampilkanData() {
        System.out.println("\n=== Data Pemain ===");
        System.out.println("Username   : " + username);
        System.out.println("Player ID  : " + playerId);
        System.out.println("Level      : " + level);
    }

    // Validasi playerId: harus 5 digit angka
    public static boolean isPlayerIdValid(String id) {
        return id.matches("\\d{5}");
    }
}
