package RPL2.pertemuanpertama;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=== Input Data Pemain ===");

        System.out.print("Masukkan Username: ");
        String username = input.nextLine();

        String playerId;
        do {
            System.out.print("Masukkan Player ID (5 digit angka): ");
            playerId = input.nextLine();
            if (!Player.isPlayerIdValid(playerId)) {
                System.out.println("Player ID TIDAK VALID! Harus 5 digit angka.");
            }
        } while (!Player.isPlayerIdValid(playerId));

        System.out.print("Masukkan Level Pemain: ");
        int level = 0;
        boolean validLevel = false;
        do {
            try {
                level = Integer.parseInt(input.nextLine());
                if (level > 0) {
                    validLevel = true;
                } else {
                    System.out.println("Level harus angka positif!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Input level harus berupa angka!");
            }
        } while (!validLevel);

        Player player = new Player(username, playerId, level);
        player.tampilkanData();

        input.close();
    }
}
