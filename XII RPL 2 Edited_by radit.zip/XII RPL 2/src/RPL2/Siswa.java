package RPL2;

public class Siswa {
public static boolean isNISValid(String nis) {
            return nis.matches("\\d{10}");
        }
    static class Tes {
        private final String nama;
        private final String nis;
        private final String kelas;
        
        public String NmDpn() {
            return nama.split(" ")[0];
        }
        
        public String NmBlkng() {
            String[] bagian = nama.split(" ");
            return bagian.length > 1 ? bagian[bagian.length - 1] : "";
        }
        
        public Tes(String nama, String nis, String kelas) {
            this.nama = nama;
            this.nis = nis;
            this.kelas = kelas;
        }
        
        public static boolean isNISValid(String nis) {
    return nis.matches("\\d{10}");
}


        public void tampilkanData() {
            System.out.println("\n=== Data Siswa ===");
            System.out.println("Nama  : " + nama);
            System.out.println("NIS   : " + nis);
            System.out.println("Kelas : " + kelas);
            System.out.println("Nama Depan  : " + NmDpn());
            System.out.println("Nama Depan  : " + NmBlkng());
        }
    }
}
