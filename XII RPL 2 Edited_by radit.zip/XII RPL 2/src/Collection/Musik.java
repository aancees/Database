package Collection;

public class Musik {
        public String judul;
        public String genre;
        public String artis;
        //public String jurusan;
        
        public Musik(String judul, String genre, String artis) {
            this.judul = judul;
            this.genre = genre;
            this.artis = artis;
        }
        
        public void tampilkanMusik() {
            System.out.println("\n=== About Musik ===");
            System.out.println("Judul  : " + judul);
            System.out.println("Genre   : " + genre);
            System.out.println("Artis : " + artis);
        }
        
        // Method String Save ke file
        public String toFile() {
            return judul + "," + genre + "," + artis;
        }
        
        //Method untuk membuat objek musik dari data string
        public static Musik fromFile(String data) {
            String[] bagian = data.split(",");
            return new Musik(bagian[0], bagian[1], bagian[2]);
        }
}
