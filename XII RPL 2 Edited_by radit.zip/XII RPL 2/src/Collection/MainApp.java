package Collection;

import java.util.*;
import java.io.*; //Import IO (FileReader, FIleWriter, Dll)
/*import java.util.ArrayList;
import java.util.Scanner;*/

public class MainApp {
    
    //Nama File untuk save data
    static final String FILE_NAME = "DataMusik.txt";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Musik> daftarMusik = new ArrayList<>();
        
        readFile(daftarMusik);
        
        boolean tryy = true;
        
        while (tryy) {
        
            System.out.println("=== MENU MUSIK FAVORITE ===");
            System.out.println("1.  Tambah Musik Favorite");
            System.out.println("2.  Tampilkan Semua");
            System.out.println("3.  Cari Berdasarkan Judul");
            System.out.println("4.  Ubah Info Musik");
            System.out.println("5.  Hapus Musik Dari Daftar");
            System.out.println("6.  Keluar");
            System.out.print("Pilih: ");
            int Select = input.nextInt();
            input.nextLine();
    
        switch (Select) {
            case 1:
                System.out.print("Judul    : ");
                String judul = input.nextLine();
                System.out.print("Genre    : ");
                String genre = input.nextLine();
                System.out.print("Artis    : ");
                String artis = input.nextLine();
                Musik s = new Musik(judul, genre, artis);
                daftarMusik.add(s);
                
                simpanKeFile(daftarMusik);
                break;
                
            case 2:
                System.out.println("=== DAFTAR SEMUA SISWA ===");
                for (Musik musik : daftarMusik) {
                        musik.tampilkanMusik();
                }
                break;
                
            case 3:
                System.out.print("Cari Judul   :");
                String cariJudul = input.nextLine();
                boolean ketemu = false;
                
                for(Musik musik  : daftarMusik) {
                    if (musik.judul.equalsIgnoreCase(cariJudul)) {
                        System.out.println("Ditemukan   :");
                        musik.tampilkanMusik();
                        ketemu = true;
                        //break;
                    }
                }
                
                if (!ketemu) {
                    System.out.println("Judul Tidak Ditemukan !");
                }
                break;
                
            case 4: 
                System.out.println("Masukan Judul Musik Yang Ingin Diubah");
                String ubahNama = input.nextLine();
                boolean ditemukan = false;
                
                for(Musik siswa : daftarMusik) {
                    if(siswa.judul.equalsIgnoreCase(ubahNama)) {
                        System.out.println("Judul Baru   :");
                        siswa.judul = input.nextLine();
                        System.out.println("Genre Baru   :");
                        siswa.genre = input.nextLine();
                        System.out.println("Artis Baru   :");
                        siswa.artis = input.nextLine();
                        
                        simpanKeFile(daftarMusik);
                        System.out.println("Data Berhasil Diubah !");
                        ditemukan = true;
                        //break;
                    }
                }
           
                if (!ditemukan) {
                    System.out.println("Data Musik Tidak Ditemukan");
                }
                break;
                
            case 5:
                System.out.println("Masukan Judul Musik Yang Ingin Dihapus");
                String hapusNama = input.nextLine();
                boolean terhapus = false;
                
                for (int i = 0; i < daftarMusik.size(); i++) {
                    if (daftarMusik.get(i).judul.equalsIgnoreCase(hapusNama)) {
                        daftarMusik.remove(i);
                        simpanKeFile(daftarMusik);
                        System.out.println("Data Berhasil Dihapus");
                        terhapus = true;
                    }
                }
                
                if (!terhapus) {
                    System.out.println("Data Musik Tidak Ditemukan !");
                }
                break;
                
            case 6:
                tryy = false;
                System.out.println("Program Selesai !");
                break;
                
            default:
                System.out.println("Pilihan Menu Tidak Valid !");
        }
     }
   }

    private static void readFile(ArrayList<Musik> daftarMusik) {
        try {
            File file = new File(FILE_NAME);
            if (!file.exists()) return;
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String baris;
            while ((baris = reader.readLine()) != null){
                Musik musik = Musik.fromFile(baris);
                daftarMusik.add(musik);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Terjadi Kesalahan saat membaca file");
        }
    }

    public static void simpanKeFile (ArrayList<Musik> daftarMusik){
        try{
            BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME));
            for (Musik musik : daftarMusik){
                writer.write(musik.toFile());
                writer.newLine();
            }
            writer.close();
        } catch (IOException e){
            System.out.println("terjadi kesalahan saat menyimpan file !!!");
        }
    }
    
}
