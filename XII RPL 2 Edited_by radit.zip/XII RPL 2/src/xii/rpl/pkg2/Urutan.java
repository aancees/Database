
package xii.rpl.pkg2;

/**
 *
 * @author SMK
 */
public class Urutan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String [] benda = {"Komputer","Cpu","Mouse","Keyboard"};
        String Urutkan;
        /*Nama benda sebelum diurutkan */
        System.out.println("Nama benda sebelum diurutkan");
        for (int i = 0; i < benda.length; i ++) {
            System.out.println(i + 1 +"" + benda[i]+"");
        }
        /*Nama benda sebelum diurutkan */
        System.out.println("\nNama benda sebelum diurutkan");
        for (int i = 0; i < (benda.length-1); i++ ) {
            for (int j = 0; j <(benda.length-1); j++){
                if (benda[j].compareTo(benda[j+1]) >0) {
                    Urutkan = benda[j+1];
                    benda[j+1]=benda[j];
                    benda[j] = Urutkan;
                }
            }
            
        }
        for (int i = 0; i <benda.length; i++){
          System.out.println(i + 1 +""+benda[i]);  
        }
            }
    
}

