 package xii.rpl.pkg2;

import java.io.Console;
public class classConsole {

/**
 *
 * @author SMK
 */
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nama;
        int usia;
        String alamat;
        
        /*membuat objek console */
        Console Con = System.console();
        /*mengisi variabel nama dan usia dengan console*/
        System.out.println("inputksn nama: ");
        nama = Con.readLine();
        System.out.println("inputksn alamat: ");
        alamat = Con.readLine();
        System.out.println("inputksn usia: ");
        usia = Integer.parseInt(Con.readLine ());
        
        /*menampilkan isi variabel nama dan usia*/
        System.out.println("nama kamu adalah " + nama);
        System.out.println("Alamat kamu di " + alamat);
        System.out.println("saat ini berusia " + usia + "Tahun");



    }
    
}
    
    

