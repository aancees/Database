/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xii.rpl.pkg2;

public class RPL {

/**
 *
 * @author SMK
 */
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         /**
     * @param args the command line arguments
     */
    
        // TODO code application logic here
        String Garis   = "======================";
        String Nama    = "Unggul";
        String Alamat  = "Varia";
        String Hobi    = "Olahraga";
        String Cita2   = "Satpam";
        
        System.out.println(Garis);
        System.out.println("Nama          =" + Nama);
        System.out.println("Alamat        =" + Alamat);
        System.out.println("Hobi          =" + Hobi);
        System.out.println("Cita2         =" + Cita2);
        System.out.println(Garis);
    }
    
}
