package materiThread;

class siswa extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Siswa : Mengerjakan Tugas.. ("+ 1 + " Menit)");
            try {
                Thread.sleep(2000);
            } catch (Exception e) {
                System.out.println("Siswa Tidak Mengerjakan Tugas!");
                
            }
        }
         System.out.println("Tugas Sudah Selesai!");
    }
}

class download extends Thread {
    public void run() {
        for (int i = 1; i <= 8; i++) {
            System.out.println("Download : Download File Dari Internet.. ("+ 1 + " Menit)");
            try {
                Thread.sleep(2500);
            } catch (Exception e) {
                System.out.println("Download Tidak Berjalan!");
                
            }
        }
        System.out.println("Download Selesai!");
    }
}

class printer extends Thread {
    public void run() {
        for (int i = 1; i <= 8; i++) {
            System.out.println("Printer : Mencetak Dokumen.. ("+ 1 + " Menit)");
            try {
                Thread.sleep(1400);
            } catch (Exception e) {
                System.out.println("Printer Tidak Berjalan!");
                
            }
        }
        System.out.println("Printer Selesai!");
    }
}

/*class download extends Thread {
    public void run() {
        for (int i = 1; 1 <= 8; i++) {
            System.out.println("Download : Download File Dari Internet.. ("+ 1 + " Menit)");
            try {
                Thread.sleep(2500);
            } catch (Exception e) {
                System.out.println("Download Tidak Berjalan!");
                
            }
             System.out.println("Download Selesai!");
        }
    }
}*/

public class Aktivitas {
    public static void main(String[] args) {
        siswa x1 = new siswa();
        download x2 = new download();
        printer x3 = new printer();
        
        x1.start();
        x2.start();
        x3.start();
        
        System.out.println("Program Utama Berjalan....");
    }
}
