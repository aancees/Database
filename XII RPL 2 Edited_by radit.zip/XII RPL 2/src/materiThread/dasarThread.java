package materiThread;

class cetakTulisan extends Thread{
    private String teks;
    
    public cetakTulisan(String teks) {
        this.teks = teks;
    }
    
    public void run() {
        for (int i = 1; i <= 111; i++) {
            System.out.println(teks + " ke-" +i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println("Thread Terganggu!");
            } 
        }
    }
}

public class dasarThread {
    public static void main(String[] args) {
        cetakTulisan t1 = new cetakTulisan("Thread A");
        cetakTulisan t2 = new cetakTulisan("Thread B");
        
        t1.start();
        t2.start();
        
        System.out.println("Program Utama Berjalan....");
    }
}
